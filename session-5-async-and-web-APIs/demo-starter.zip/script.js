const catfact = document.querySelector('#cat-fact');
const catbtn = document.querySelector('#cat-btn');
const inputnum = document.querySelector('#input-number');
const numbtn = document.querySelector('#num-btn');
const numberfact = document.querySelector('#number-fact');

const getCatFactFromAPI = () => {
	// TODO
}

catbtn.addEventListener("click", getCatFactFromAPI);


//Challenge Time! 
// Read the API reference in: http://numbersapi.com
// to display a number fact on the webpage!
// The DOM API ground work has been done for you :)
// You only need to worry about the TODO sections.
const getNumberFact = () => {
    // Challenge TODO
}

numbtn.addEventListener("click", getNumberFact);


